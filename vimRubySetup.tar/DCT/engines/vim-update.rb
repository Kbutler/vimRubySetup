#!/usr/bin/env ruby
#List of vim packages to be installed from GIT.
#Variable part to a file argument.
#Generic static engine remaining untouched with each new variable file.
#Store variable file in a seperate repository.
#Used to sync machines and new set up
#
gitBundles = []

ARGV.each do |vimFile|
  File.open(vimFile, "r").each{ |line|
      gitBundles << line.chomp
}
end

vimPath = gitBundles[0]
gitBundles.delete_at(0)

vim_org_scripts = [
  ["IndexedSearch", "7062",  "plugin"],
  ["jquery",        "12107", "syntax"],
]

require 'fileutils'
require 'open-uri'

FileUtils.cd(vimPath)

puts "Trashing everything (lookout!)"
Dir["*"].each {|d| FileUtils.rm_rf d }

gitBundles.each do |url|
  dir = url.split('/').last.sub(/\.git$/, '')
  puts "  Unpacking #{url} into #{dir}"
  `git clone #{url} #{dir}`
  FileUtils.rm_rf(File.join(dir, ".git"))
end

vim_org_scripts.each do |name, script_id, script_type|
  puts "  Downloading #{name}"
  local_file = File.join(name, script_type, "#{name}.vim")
  FileUtils.mkdir_p(File.dirname(local_file))
  File.open(local_file, "w") do |file|
    file << open("http://www.vim.org/scripts/download_script.php?src_id=#{script_id}").read
  end
end
